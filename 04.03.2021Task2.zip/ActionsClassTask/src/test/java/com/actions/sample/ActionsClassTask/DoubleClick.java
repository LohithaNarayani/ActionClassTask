package com.actions.sample.ActionsClassTask;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@Test
public class DoubleClick {

	public static void main(String[] args) {
		WebDriver driver = null;
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
		 driver = new ChromeDriver(); 
		
		//Double click
		 Actions action = new Actions(driver);
		driver.get("https://demoqa.com/buttons");
		driver.manage().window().maximize();
		
		WebElement dblclick= driver.findElement(By.id("doubleClickBtn"));
		action.doubleClick(dblclick).build().perform();
		
		//Context click action
		WebElement rightclick= driver.findElement(By.id("rightClickBtn"));
		action.contextClick(rightclick).build().perform();
	}

}
