package com.actions.sample.ActionsClassTask;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@Test
public class MouseHover {

	public static void main(String[] args) {
		WebDriver driver = null;
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
		 driver = new ChromeDriver(); 
		 
		 //mouse hover action
		Actions action = new Actions(driver);
		driver.get("https://demoqa.com/menu");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		WebElement menuOption = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/a"));
		 action.moveToElement(menuOption).perform();
		 
		 WebElement subMenuOption = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/ul/li[3]/a"));   
	     action.moveToElement(subMenuOption).perform();

	}

}
