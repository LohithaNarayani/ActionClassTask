package com.actions.sample.ActionsClassTask;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ParentChildWindowHandles {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = null;
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.get("https://demoqa.com/browser-windows");
		 
		 String ParentHandle = driver.getWindowHandle();
		 System.out.println("Parent Window:-"+ParentHandle);
		 
		 driver.findElement(By.id("windowButton")).click();
		 Set<String> handles = driver.getWindowHandles();
		 for(String handle : handles) {
			 System.out.println(handle);
			 if(!handle.equals(ParentHandle)) {
				 driver.switchTo().window(handle);
				 System.out.println(driver.switchTo().window(handle).getTitle());
				 Thread.sleep(4000);
				 driver.close();
			 }
		 }
		 Thread.sleep(2000);
		 //driver.quit();
		
	}

}
