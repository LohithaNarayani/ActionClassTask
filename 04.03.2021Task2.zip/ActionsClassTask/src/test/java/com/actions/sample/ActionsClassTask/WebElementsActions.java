package com.actions.sample.ActionsClassTask;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@Test
public class WebElementsActions {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = null;

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//drivers//chromedriver.exe");
		driver = new ChromeDriver();

		// move to element action
		Actions action = new Actions(driver);
		driver.get("https://demoqa.com/interaction");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		action.moveToElement(driver.findElement(By.className("header-wrapper"))).build().perform();

		// draganddrop action

		driver.get("https://demoqa.com/droppable/");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,200)");

		WebElement from = driver.findElement(By.id("draggable"));
		WebElement to = driver.findElement(By.id("droppable"));
		// action.clickAndHold(from).moveToElement(to).release().build().perform();
		action.dragAndDrop(from, to).build().perform();
		Thread.sleep(3000);

		// mouse hover action

		driver.get("https://demoqa.com/menu");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		WebElement menuOption = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/a"));
		action.moveToElement(menuOption).perform();

		WebElement subMenuOption = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/ul/li[3]/a"));
		action.moveToElement(subMenuOption).perform();
		Thread.sleep(3000);

		// DoubleClick

		driver.get("https://demoqa.com/buttons");
		driver.manage().window().maximize();

		WebElement dblclick = driver.findElement(By.id("doubleClickBtn"));
		action.doubleClick(dblclick).build().perform();
		Thread.sleep(3000);

		// Context click action
		WebElement rightclick = driver.findElement(By.id("rightClickBtn"));
		action.contextClick(rightclick).build().perform();
		Thread.sleep(3000);

		// Send input text

		driver.get("https://demoqa.com/text-box");
		driver.manage().window().maximize();

		driver.findElement(By.id("userName")).sendKeys("LohithaNarayani");
		driver.findElement(By.id("userEmail")).sendKeys("lohitha@gmail.com");
		driver.findElement(By.id("currentAddress")).sendKeys("11-234,Gandhipuram street,Hyderabad");
		driver.findElement(By.id("permanentAddress")).sendKeys("11-234,Gandhipuram street, Hyderabad");
		Thread.sleep(2000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,200)");
		driver.findElement(By.xpath("//*[@id=\"submit\"]")).submit();

		// Switch to new tab action
		driver.get("https://demoqa.com/tabs");
		driver.manage().window().maximize();

		driver.findElement(By.id("demo-tab-origin")).click();

		driver.get("https://demoqa.com/browser-windows");

		String ParentHandle = driver.getWindowHandle();
		System.out.println("Parent Window:-" + ParentHandle);

		driver.findElement(By.id("tabButton")).click();
		Thread.sleep(3000);

	}

}
