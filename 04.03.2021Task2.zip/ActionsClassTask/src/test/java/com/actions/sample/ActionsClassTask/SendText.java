package com.actions.sample.ActionsClassTask;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@Test
public class SendText {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = null;
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
		 driver = new ChromeDriver(); 
		
		//Send input text 
		// Actions action = new Actions(driver);
		driver.get("https://demoqa.com/text-box");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("userName")).sendKeys("LohithaNarayani");
		driver.findElement(By.id("userEmail")).sendKeys("lohitha@gmail.com");
		driver.findElement(By.id("currentAddress")).sendKeys("11-234,Gandhipuram street,Hyderabad");
		driver.findElement(By.id("permanentAddress")).sendKeys("11-234,Gandhipuram street, Hyderabad");
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,200)");
		driver.findElement(By.xpath("//*[@id=\"submit\"]")).submit();
		

	}

}
