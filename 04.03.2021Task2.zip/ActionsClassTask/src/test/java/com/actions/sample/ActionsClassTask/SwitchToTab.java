package com.actions.sample.ActionsClassTask;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@Test
public class SwitchToTab {

	public static void main(String[] args) {
		WebDriver driver = null;
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
		 driver = new ChromeDriver(); 
		
		//Switch to new tab action
		 Actions action = new Actions(driver);
		driver.get("https://demoqa.com/tabs");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("demo-tab-origin")).click();
		
		driver.get("https://demoqa.com/browser-windows");
		 
		 String ParentHandle = driver.getWindowHandle();
		 System.out.println("Parent Window:-"+ParentHandle);
		 
		 driver.findElement(By.id("tabButton")).click();

	}

}
